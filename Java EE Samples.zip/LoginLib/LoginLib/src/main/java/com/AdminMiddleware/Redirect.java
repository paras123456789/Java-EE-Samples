package com.AdminMiddleware;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Redirect extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		String UserRole = "";
		
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("session");
		
		/* checking current session ID , if isAdmin or user then redirecting to respective dashboard */
		if(username.equals("paras")) {
			UserRole = "admin";
		}else {
			UserRole = "customer";
		}
		
		switch(UserRole) { 
			
		case "admin":
			response.sendRedirect("adminDashboard");
			break;
			
			default:
		    session.removeAttribute("session");
		    session.setAttribute("errorNotAdmin","Unable to login");
			response.sendRedirect("Login");
			break;
			
		
		}
		
	}


}
