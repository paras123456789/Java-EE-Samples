package com.LoginControllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AdminDashboard
 */
public class AdminDashboard extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session = request.getSession();
		
		PrintWriter out = response.getWriter();
		
		if(null == session.getAttribute("session")){
			response.sendRedirect("Login");
		}else {
			request.getRequestDispatcher("/WEB-INF/admin/home.jsp").forward(request, response);
		}
//		if(session.getAttribute("session").equals(null)){
//			response.sendRedirect("notlLoggedInAsAdmin");
//		}else{
//			request.getRequestDispatcher("/WEB-INF/admin/home.jsp").forward(request, response);
//		}
		
	
	}


}
