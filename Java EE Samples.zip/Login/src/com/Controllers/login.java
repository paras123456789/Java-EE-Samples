package com.Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Controllers.DB;
import com.Models.Get;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String userid = request.getParameter("user_id");
		Connection conn = null;
		
		try {
			
			PrintWriter pt = response.getWriter();
			
			
			conn = DB.createConnection();
			Statement stmt = conn.createStatement();
			
			
//			Class.forName("com.mysql.jdbc.Driver");
//			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
//			Statement stmt = conn.createStatement();
//			
//			String Username =userid;
//			ResultSet rsmt = stmt.executeQuery("SELECT * FROM users WHERE username='"+Username+"' ");
//			
////			int rs = stmt.executeUpdate("insert into users(username) values('"+sql+"')");
//			
//			if(rsmt.next()){
//				pt.print("success");
//			}else {
//				pt.print("error");
//			}
		
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		
//		String valid = login(response);
	
		
		
	}

}
