package com.Controllers;

import java.sql.*;

public class DB {

	public static Connection createConnection() throws SQLException {
		
		Connection con = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
			
		} catch (ClassNotFoundException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}
	
}
