package com.Models;

import java.sql.*;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class Get{
	
	public void login(String str,HttpServletResponse response) {
	
		
		
		
		String sql = "parasss";
		String val = "";
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
			Statement stmt = conn.createStatement();
			ResultSet rsmt = stmt.executeQuery("select * from users where username = 'paras' ");
//			int rs = stmt.executeUpdate("insert into users(username) values('"+sql+"')");
			
			
			PrintWriter pt = response.getWriter();
			pt.append("shjashjashajsh");
			
//			val = String.valueOf(count);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
//		return val;
	}

}
