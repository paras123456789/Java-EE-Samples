package com.paras.SampleWeb;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class WebSrap {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Document doc = Jsoup.connect("https://www.shoppersstop.com/men-clothing-t-shirts/c-A101010").userAgent("Chrome").get();
		
		System.out.println(doc.select("ul#qv-drop").html());
		

	}

}
