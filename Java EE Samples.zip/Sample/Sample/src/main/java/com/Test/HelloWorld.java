package com.Test;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class HelloWorld extends HttpServlet{
	private static final long serialVersionUID = 1L;

    public HelloWorld(){
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stubrequest.getContextPath()
		String UserRole = "user";
		
		request.getRequestDispatcher("/WEB-INF/sample.jsp").forward(request, response);
//		response.sendRedirect("/WEB-INF/sample.jsp");
		
//		if(UserRole.equals("Admins")){
//			HttpSession session = request.getSession();
//			session.setAttribute("role","admin");
//			response.sendRedirect("admin/home.jsp");
//		}else if(UserRole == "user"){
//			HttpSession session = request.getSession();
//			session.setAttribute("role","user");
//			response.sendRedirect("user/home.jsp");
//		}else {
//			response.sendRedirect("index.jsp");
//		}
		
//		response.getWriter().append("Served at: ").append("hello javasssss");
	}


}
