package com.Test;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.simple.JSONArray;

//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		List<Foo> foos = new ArrayList<Foo>();
//		foos.add(new Foo("demo","fdemo");
//		foos.add(new Foo("test","fname");
		
//		Map<String, String> mymap = new HashMap<String, String>();
//		mymap.put("one", "1");
//		mymap.put("two", "2"); 
//		
//		System.out.println(mymap.get("one"));
		
		
		  JSONObject o1 = new JSONObject();
		  o1.put("name", "Alex");
		  o1.put("roll", new Integer(12));
		  o1.put("total_marks", new Double(684.50));
		  o1.put("pass", new Boolean(true));
//		  System.out.print(o1);
		  
		  JSONObject o2 = new JSONObject();
		  o2.put("props",o1);
		  System.out.println(o2);
//		
//		 String s = "{\"total_marks\":684.5,\"pass\":true,\"name\":\"Alex\",\"roll\":12}";
//		  Object o1 = JSONValue.parse(s);
//		  JSONObject jsonObj = (JSONObject) o1;
//		  String name = (String) jsonObj.get("name");
//		  Integer out = Integer.class.cast(jsonObj.get("roll")).intValue();
//		  double marks = (Double) jsonObj.get("total_marks");
//		  Integer roll = (Integer)jsonObj.get("roll");
//		  System.out.println(name + " " + marks + " " + roll);
//		  System.out.println(roll);
		 
		 
		 
		    String s="{\"props\":{\"total_marks\":684.5,\"pass\":true,\"name\":\"Alex\",\"roll\":12}}";  
		    Object obj=JSONValue.parse(s);  
		    JSONObject jsonObject = (JSONObject) obj;  
//		  
//		    String name = (String) jsonObject.get("name");  
//		    double salary = (Double) jsonObject.get("total_marks");
////		    long age = (Long) jsonObject.get("age");
//		    Number roll = (Number) jsonObject.get("roll");
//		    System.out.println(name+" "+roll);
//		    
//		    
//		    JSONArray arr = new JSONArray();  
//		    arr.add("sonoo");   
//		    arr.add(new Integer(27));    
//		    arr.add(new Double(600000));   
//		    System.out.print(arr); 
		    
//		    JSONObject myjson = new JSONObject(jsonObject);
//		    JSONArray the_json_array = myjson.getJSONArray(",yjson");
		    
//		    int size = myjson.size();
//		    ArrayList<JSONObject> arrays = new ArrayList<JSONObject>();
//		    for (int i = 0; i < size; i++){
////		        JSONObject another_json_object = the_json_array.getJSONObject(i);
//		    	System.out.println(arrays.get(i));
//		    }
		    
		    for (Object keyStr : jsonObject.keySet()){
		         Object keyvalue = jsonObject.get(keyStr);        
		         
		        //Print key and value
//		        System.out.println("key: "+ keyStr + " value: " + keyvalue);

		        //for nested objects iteration if required
		        //if (keyvalue instanceof JSONObject)
		        //    printJsonObject((JSONObject)keyvalue);
		    }
		    
		    Object values = jsonObject.get("props");
//		    System.out.println(values);
	         Object objs = JSONValue.parse(values.toString());
	         JSONObject jobj = (JSONObject) objs;
	         Number num = (Number) jobj.get("roll");
	         System.out.println(jobj.get("name") +""+ num);
		    

		    
		 
		 
		 }
		  
		  
	

}
