package com.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM users");
			
//			request.setAttribute("data",rs.getInt(0));
			PrintWriter pt = response.getWriter();

			List<DataList> lists = new ArrayList<DataList>();
			while(rs.next()) {
				DataList ls = new DataList();
				ls.setName(rs.getString(2));
				lists.add(ls);
						
			}
			request.setAttribute("data",lists);
			request.getRequestDispatcher("index.jsp").forward(request, response);
//			
//			request.setAttribute("list",lists);
			
				
			   ArrayList Rows = new ArrayList();
			   
			       ArrayList row = new ArrayList();
			
//			       while(rs.next()){
////						pt.print(rs.getInt(1));
//						 row.add(rs.getInt(1));
//						 row.add(rs.getString(2));
//				   }
//			       Rows.add(row);
//
//			request.setAttribute("DataList", row);
////			
//			ArrayList results = (ArrayList) request.getAttribute("DataList");
//			
//			pt.print(results.);
//			for(int i=0; i<=results.size(); i++) {
//				
//				pt.println(results.get(2));
//				
//			}
			
//			
//			request.getRequestDispatcher("index.jsp").forward(request, response);
//			return;
//			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
