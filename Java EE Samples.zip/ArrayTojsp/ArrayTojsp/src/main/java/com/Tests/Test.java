package com.Tests;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.ArrayList;
/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM users");
			
//			request.setAttribute("data",rs.getInt(0));
			PrintWriter pt = response.getWriter();
			
				
			   ArrayList Rows = new ArrayList();

			       ArrayList row = new ArrayList();
			       for (int i = 1; i <=2; i++){
			           row.add(rs.getString(i));
			       }
			       Rows.add(row);
//
			request.setAttribute("DataList", Rows);
//			
			request.getRequestDispatcher("index.jsp").forward(request, response);
//			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}


}
