package com.paras.WebScrap;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;

public class WebSrap1 {

	public static void main(String[] args) throws UnsupportedEncodingException, IOException {
	
//		String google = "http://www.google.com/search?q=site:linkedin.com 'CEO',size=10 ";
//		String  google = "https://www.google.com/search?q=site:linkedin.com+%22CEO%22,size%3D10&rlz=1C1CHBF_enIN863IN863&ei=rV2CXZ_PE9X59QPNp4rwBg&start=10&sa=N&ved=0ahUKEwjf2ZfP59rkAhXVfH0KHc2TAm4Q8tMDCJ4B&biw=811&bih=657";
		String search = "site:linkedin.com 'CEO',size=10 ";
		String charset = "UTF-8";
		String userAgent = "ExampleBot 1.0"; // Change this to your company's name and bot homepage!
	String google = "https://www.google.com/search?q=site:linkedin.com+%22CEO%22,size%3D10&rlz=1C1CHBF_enIN863IN863&biw=811&bih=657&ei=LWGCXcCQIIbgrQH-up3QBA&start=20&sa=N&ved=0ahUKEwiA28P66trkAhUGcCsKHX5dB0o4ChDy0wMIjAE&num=100";
		
		Document doc = Jsoup.connect(google).userAgent("Mozilla/5.0").get();
		//doc.select("div#main").select("div.ZINbbc").select("div.kCrYT")
		//div#st-card
		Elements parent = doc.select("div#main").select("div.ZINbbc");
		
		int i = 1;
		for(Element element : parent.select("div.xpd")) {
			int count = i++;
			String str = element.select("div.kCrYT").select("div.vvjwJb").text();
			if(str.equals("")) {
				
			}else {
				System.out.println(count+": "+element.select("div.kCrYT").select("div.vvjwJb").text());
			}
//			if(count <= i) {
//				
//			}
		}
		
		//nonce="asvfHH8bJMxPd8fBXZ5sVg==">(function()
		
//		System.out.println(parent); //parent
		
		
		
		
	}

}
